﻿app.controller("GroupController", function ($scope, $http) {
    $scope.model = {};
    $scope.Detmodel = {};
    $scope.model.txtSearch = "";
    $scope.model.IsEdit = false;
    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }

    $scope.GroupSearch=function()
    {
        $("#mainGrid").data("kendoGrid").dataSource.read();
    }
     
    $scope.mainGridOptions = {
        dataSource: {
            type: "json",
            transport: {
                read: {
                    url: baseUrl + "Group/GetGroup",
                    dataType: "json",
                },
                parameterMap: function (options, operation) {
                    debugger;
                    var opt = {};
                    opt = options;
                    opt.Search = $scope.model.txtSearch;
                    return opt;
                },
            },
            schema:
                    {
                        model:
                        {
                            id: "Id",
                            fields: {
                               
                            }
                        }
                    },

            serverPaging: true,
            schema: {
                data: function (response) {
                    if (response.Result) {
                        return JSON.parse(response.Result);
                    }
                    return [];
                },
                total: 'Total',

            }
        },

        sortable: {
            mode: "single",
            allowUnsort: true
        },


        pageable: { pageSize: GridPageSize, refresh: true },

        resizeable: true,
        scrollable: false,
        //dataBound: function () {
        //    this.expandRow(this.tbody.find("tr.k-master-row").first());
        //},
        //specify columns that you want to display   
        columns: [
               {
               field: "Name",
               title: "Group Name",
               width: "80px",
               filterable: false,

               },
                 {
                     field: "description",
                     title: "Description",
                     width: "80px",
                     filterable: false,

                 },
                 {
                     field: "createdby",
                     title: "Created By",
                     width: "80px",
                     filterable: false,
                 },
                  {
                      field: "createddate", title: "Created Date", width: "80px",
                      type: "date",
                      format: "{0:dd-MMM-yyyy hh:mm tt}"
                  },

          
           {
               template: "<a href='javascript:void(0);' class='btn-edit'  ng-click='GroupPopup(this)'  data-toggle='tooltip' title='Edit'><i class='las la-pen'></i></a> &nbsp; <a href='javascript:void(0);' class='btn-delete' ng-click='deleteGroup(this)'  data-toggle='tooltip' title='Delete'><i class='las la-trash-alt'></i></a>",
               width: "40px",
               title: "Action",
               headerAttributes: { style: "text-align:center;" },
               attributes: { style: "text-align:center;" },
           },

        ]
    };
    $scope.subgridOptions = function (dataItem) {
        return {
            dataSource: {
                type: "json",
                transport: {
                    read: {
                        url: baseUrl + "Group/GetGroupDetails",
                        dataType: "json"
                    },
                    parameterMap: function (options, operation) {
                        debugger;
                        var opt = {};
                        opt = options;
                        opt.GroupId = dataItem.Id;
                        return opt;
                    },
                },

                serverPaging: true,
                schema: {
                    data: function (response) {
                        if (response.Result) {
                            return JSON.parse(response.Result);
                        }
                        return [];
                    },
                    total: 'Total',

                }

            },
            scrollable: false,
            sortable: true,
            pageable: { pageSize: GridPageSize, refresh: true },
            toolbar: [
        {
            template: "<a href='javascript:void(0);' class='btn btn-primary-o btn-sm' id='actionButton'     ng-click='GroupDetailPopup(this,\"Add\")'  data-container='body' title='Add'>Add Branch</a>"
        }
      ],     
            columns: [
          
          {
              field: "BranchName",
              title: "Branch",
              width: "80px",
              filterable: false,
          },
           {
               field: "createdby",
               title: "Created By",
               width: "80px",
               filterable: false,
           },
           {
               field: "createddate", title: "Created Date", width: "80px",
               type: "date",
               format: "{0:dd-MMM-yyyy hh:mm tt}"
           },
           {
               template: "<a href='javascript:void(0);' class='btn-edit'  ng-click='GroupDetailPopup(this,\"Edit\")'  data-toggle='tooltip' title='Edit'><i class='las la-pen'></i></a> &nbsp; <a href='javascript:void(0);' class='btn-delete' ng-click='deleteGroupDetails(this)'  data-toggle='tooltip' title='Delete'><i class='las la-trash-alt'></i></a>",
               width: "40px",
               title: "Action",
               headerAttributes: { style: "text-align:center;" },
               attributes: { style: "text-align:center;" },
           },
            ]
        };
    };



    $scope.AddGroup = function (e) {
        $("span.k-tooltip-validation").hide();
        $scope.clearFields();
        $scope.winOptions = {
            title: "Add (New)",           
        }
        $scope.WinGroup.setOptions($scope.winOptions);
        $scope.WinGroup.open().center();
    }

    $scope.GroupPopup = function (e) {
        debugger
        $("span.k-tooltip-validation").hide();
        if (e.dataItem != null) {
            var dataItem = e.dataItem;
            if (dataItem) {               
                $scope.model.Id = dataItem.Id;
                //$("#BranchId").data('kendoComboBox').dataSource.read();
                //$scope.model.BranchId = dataItem.branch_id;                                         
                //$scope.model.BranchName = dataItem.BranchName;
                //$("#BranchId").data('kendoComboBox').value(dataItem.branch_id);
                $scope.model.Name = dataItem.Name;
                $scope.model.Description = dataItem.description;                                         
                $scope.model.BtnName = "Update";                            
              



            }
            else {
                $scope.clearFields();
            }
        }
        else {
          //  $scope.model.IsEdit = false;
            $scope.clearFields();
            $scope.model.BtnName = "Submit";
        }

       
        $scope.winOptions = {
            title: dataItem == null ? "Add (New)" : "Edit",
            // activate: $scope.activate
        }
        $scope.WinGroup.setOptions($scope.winOptions);
        $scope.WinGroup.open().center();

    };


    $scope.GroupDetailPopup = function (e,type) {
        debugger
        $("span.k-tooltip-validation").hide();
        if (type == 'Add') {
            $scope.Detmodel = {};
            $scope.Detmodel.Id = '';
            $scope.Detmodel.IsEdit = false;
            $scope.Detmodel.group_id =  e.dataItem.Id;
            $scope.Detmodel.branch_id ='';
            $scope.Detmodel.BtnName = "Submit";
            SetMultiSelectorValue("BranchIds", null);
          
        }
        else
        {
            if (e.dataItem != null) {
                var dataItem = e.dataItem;
                if (dataItem) {
                    $scope.Detmodel = {};
                    $scope.Detmodel.IsEdit = true;
                    $scope.Detmodel.Id = dataItem.Id;
                    $scope.Detmodel.group_id = dataItem.group_id;
                    $scope.Detmodel.BranchName = dataItem.BranchName;
                    $("#BranchId").data('kendoComboBox').dataSource.read();
                    $scope.Detmodel.BranchId = dataItem.branch_id;
                    $("#BranchId").data('kendoComboBox').value(dataItem.branch_id);
                    $scope.Detmodel.BtnName = "Update";
                }
                else {
                    $scope.clearDetFields();
                }
            }
        }
         
        $scope.winOptions = {
            title: dataItem == null ? "Add (New)" : "Edit",         
        }
        $scope.WinDetailGroup.setOptions($scope.winOptions);
        $scope.WinDetailGroup.open().center();

    };

    $scope.clearDetFields = function () {
        $scope.Detmodel = {};
        $scope.Detmodel.Id = '';
        $scope.Detmodel.IsEdit = false;
        $scope.Detmodel.group_id = '';
        $scope.Detmodel.branch_id = '';
        $scope.Detmodel.BtnName = "Submit";
        SetMultiSelectorValue("BranchIds", null);
    }
    $scope.clearFields = function () {
        $scope.model = {};
        $scope.model.Id = '';
     //   $scope.model.IsEdit = false;
        $scope.model.Id = "";     
        //$scope.model.BranchName = "";
        $scope.model.Name = "";
        $scope.model.Description = "";
        $scope.model.BtnName = "Submit";
        //SetMultiSelectorValue("BranchIds", null);
    }

    $scope.Cancel = function (e) {
        $scope.WinGroup.close();
    };

    $scope.DetCancel = function (e) {
        $scope.WinDetailGroup.close();
    };



    $scope.BranchDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: baseUrl + "Group/GetBranch"
                }
            }
        },
        filter: "contains",
        suggest: true
    };
   

    $scope.OnBranchComboBoxChange = function (e) {
        debugger;
        var valid = comboBoxClearInavlidEntry(e);
        if (!valid)
        {       
            SetComboValue("BranchId", null);
             
        }
    }

 
    

    $scope.Save = function () {
        debugger
        if ($scope.validator.validate()) {
            $scope.ShowLoaderImg();
                var Group =
                   {
                       Id: $scope.model.Id,
                       Name: $scope.model.Name,                                      
                       Description: $scope.model.Description
                     
                    
                   };

            
           

            $http({
                method: 'POST',
                url: baseUrl + 'Group/SubmitInfo',
                data: Group,
            }).then(function (response) {
                debugger;
                $scope.HideLoaderImg();                             
                 if (response.data == 'error') {
                    SetMessage('Error')
                 }
                 else if(response.data == 'exists')
                 {
                     SetMessage('Exist')
                 }
                else {
                   $scope.WinGroup.close();
                    SetMessage('Save')
                    $("#mainGrid").data("kendoGrid").dataSource.read();
                }

            }, function errorCallback(response) {
                $scope.HideLoaderImg();
                SetMessage('Error');

            });

           
        }
    }


    $scope.SaveDetails = function () {
        debugger
        if ($scope.DetValidator.validate()) {
            $scope.ShowLoaderImg();
            var branchIds = '';
            if (!$scope.Detmodel.IsEdit) {
                branchIds = $("#BranchIds").data('kendoMultiSelect').value().toString();
            }


            var Group =
               {
                   Id: $scope.Detmodel.Id,
                   group_id:$scope.Detmodel.group_id,
                   branch_id: getComobBoxValue("BranchId"),                 
                   BranchIds: branchIds

               };

            $http({
                method: 'POST',
                url: baseUrl + 'Group/SubmitDetails',
                data: Group,
            }).then(function (response) {
                debugger;
                $scope.HideLoaderImg();
                if (response.data == 'error') {
                    SetMessage('Error')
                }
                else if (response.data == 'exists') {
                    SetMessage('Exist')
                }
                else {
                    $scope.WinDetailGroup.close();
                    SetMessage('Save')
                    $("#childGrid").data("kendoGrid").dataSource.read();
                }

            }, function errorCallback(response) {
                $scope.HideLoaderImg();
                SetMessage('Error');

            });


        }
    }
    

    $scope.deleteGroupDetails = function (e) {
        $scope.DeleteModel = {};
        var warnText = "Are you sure you want to delete this record?";
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                $scope.ShowLoaderImg();
                $scope.DeleteModel.Id = e.dataItem.Id;
                $http({
                    method: 'POST',
                    url: baseUrl + 'Group/DeleteDetails',
                    data: $scope.DeleteModel,
                }).then(function (response) {
                    debugger;
                    $scope.HideLoaderImg()
                    SetMessage('Delete')
                    $("#childGrid").data("kendoGrid").dataSource.read();


                }, function errorCallback(response) {
                    $scope.HideLoaderImg();
                    SetMessage('Error');

                });
            }
        });
    }




    $scope.deleteGroup= function (e) {
        $scope.DeleteModel = {};
        var warnText = "Are you sure you want to delete this record?";
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                $scope.ShowLoaderImg();
                $scope.DeleteModel.Id = e.dataItem.Id;               
                $http({
                    method: 'POST',
                    url: baseUrl + 'Group/Delete',
                    data: $scope.DeleteModel,
                }).then(function (response) {
                    debugger;
                    $scope.HideLoaderImg()
                    SetMessage('Delete')
                    $("#mainGrid").data("kendoGrid").dataSource.read();


                }, function errorCallback(response) {
                    $scope.HideLoaderImg();
                    SetMessage('Error');

                });
            }
        });
    }




});