﻿app.controller("ReportController", function ($scope, $http) {
    $scope.model = {};
    $scope.model.txtSearch = "";
    $scope.model.FromDate = moment().subtract(30, "days").format("DD-MM-YYYY");
    $scope.model.ToDate = moment().add(1, 'days').format("DD-MM-YYYY");

    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }

    $scope.reportGridOptions = {
        dataSource: {
            type: "json",
            transport: {
                read: {
                    url: baseUrl + 'Report/GetAllItemsReport',
                    dataType: "json",
                },
                parameterMap: function (options, operation) {
                    debugger;
                    var opt = {};
                    opt = options;
                    opt.Search = $scope.model.txtSearch;
                    opt.FromDate = $scope.model.FromDate;
                    opt.ToDate = $scope.model.ToDate;
                    return opt;
                },
            },
            schema:
                    {
                        model:
                        {
                            id: "Id",
                            fields: {


                            }
                        }
                    },

            serverPaging: true,
            schema: {
                data: function (response) {
                    if (response) {
                        return JSON.parse(response.Result);
                    }
                    return [];
                },
                total: 'Total',

            }
        },
        sortable: {
            mode: "single",
            allowUnsort: true
        },
        pageable: { pageSize: GridPageSize, refresh: true },
        resizeable: true,
        scrollable: false,
        toolbar: [

        {
            template: "&nbsp;<a href='javascript:void(0);' class='btn btn-export'  ng-click='exportToExcel(\"report\")' data-toggle='tooltip' title='Export to Excel'><i class='fa fa-file-excel-o'></i></a>",
        }
        ],
        columns: [

            {
                field: "MessageDetailId",
                hidden: true,


            },
            {
                field: "Subject",
                title: "Subject",
                width: "80px",
                filterable: false,


            },
              {
                  field: "Message",
                  title: "Message",
                  width: "80px",
                  filterable: false,


              },
              {
                  field: "Reply",
                  title: "Reply",
                  width: "80px",
                  filterable: false,


              },


            {
                field: "BranchName",
                title: "Branch",
                width: "80px",
                filterable: false,
            },
             {
                 field: "EmployeeName",
                 title: "Employee",
                 width: "80px",
                 filterable: false,
             },



               {
                   field: "StatusName",
                   title: "Status",
                   width: "120px",
                   filterable: false,
               },
                {
                    field: "DeletedStatus",
                    title: "Is Deleted",
                    width: "120px",
                    filterable: false,
                },


               {
                   field: "CreatedBy",
                   title: "Created By",
                   width: "60px",
                   filterable: false,
               },
                 {
                     template: "<a href='javascript:void(0);' class='btn btn-export'  ng-click='exportChat(this)'  data-toggle='tooltip' title='Export Chat'><i class='fa fa-file-excel-o'></i></a>",
                     width: "40px",
                     title: "Action",
                     headerAttributes: { style: "text-align:center;" },
                     attributes: { style: "text-align:center;" },
                 },

        ]
    };

    $scope.checkData = function (e) {
        $("#ReportGrid").data("kendoGrid").dataSource.read();
    }


    $scope.exportChat = function (e) {
        debugger;

        $http({
            method: 'POST',
            url: baseUrl + 'Report/GetAllChat?Id=' + e.dataItem.MessageDetailId,
            // data: $scope.PostModel
        }).then(function (response) {
            debugger;

            var result = response.data;
            if (result.length != 0) {
                var TableResult = convertJSONtoTableChat(result, e.dataItem);
                $(TableResult).hide().appendTo("body")
                $("#exportChatTable").table2excel({
                    name: "Table2Excel",
                    filename: "Chat",
                    fileext: ".xlsx"
                });
            }
            else {
                SetMessage("NoData");
            }

            HideLoader();

        }, function errorCallback(response) {
            HideLoaderImg();


        });


    }


    $scope.exportToExcel = function () {
        debugger
        $scope.PostModel = {};
        $scope.PostModel.FromDate = $scope.model.FromDate;
        $scope.PostModel.ToDate = $scope.model.ToDate;
        $http({
            method: 'POST',
            url: baseUrl + 'Report/GetAllItemsForExport',
            data: $scope.PostModel
        }).then(function (response) {
            debugger;

            var result = response.data;
            if (result.length != 0) {
                var TableResult = convertJSONtoTable(result);
                $(TableResult).hide().appendTo("body")
                $("#exporttable").table2excel({
                    name: "Table2Excel",
                    filename: "Message",
                    fileext: ".xlsx"
                });
            }
            else {
                SetMessage("NoData");
            }

            HideLoader();

        }, function errorCallback(response) {
            HideLoaderImg();


        });



    };


    function convertJSONtoTable(response) {
        $("#exporttable").remove();
        var result = "<table id='exporttable'>";

        var keysHtml = [];
        var keysHtmlformat = [];
        var flag = 0;

        response.forEach(function (obj, idx) {
            var gridname = 'ReportGridExcel';
            if (flag == 0) {
                var columns = $("#ReportGrid").data("kendoGrid").columns
                result = result + "<thead><tr>";
                if (columns.length > 0) {
                    for (var i = 0; i < columns.length; i++) {
                        var col = columns[i];
                        if (col.attributes != undefined && col.attributes.style.search("display:none") >= 0)
                            continue;

                        if (col.field != undefined && col.hidden != true) {
                            result = result + "<th><b>" + col.title + "</b></th>"; // adding Grid header names
                            keysHtml.push(col.field);
                            keysHtmlformat.push(col.format);
                        }
                    }
                }
                result = result + "</tr></thead><tbody>";
            }
            result = result + "<tr>";
            keysHtml.forEach(function (key, idx) {
                var itemVal = obj[key];
                if (itemVal != null) {
                    var itemVal2 = itemVal.toString();
                }
                else {
                    itemVal = "";
                }

                result = result + "<td>" + itemVal + "</td>";    // adding indivisual cell values
            });
            result = result + "</tr>";
            flag = 1;
        });

        result = result + "</tbody></table>";
        return result;
    }



    function convertJSONtoTableChat(response, details) {
        var executed = 0;
        $("#exportChatTable").remove();
        var result = "<table id='exportChatTable'>";

        var keysHtml = [];
        var keysHtmlformat = [];
        var flag = 0;
        debugger;
        response.forEach(function (obj, idx) {
            var gridname = 'ChartGridExcel';
            if (flag == 0) {
                var columns = $("#ChartGridExcel").data("kendoGrid").columns
                result = result + "<thead><tr>";
                if (columns.length > 0) {
                    for (var i = 0; i < columns.length; i++) {
                        var col = columns[i];
                        if (col.attributes != undefined && col.attributes.style.search("display:none") >= 0)
                            continue;

                        if (col.field != undefined && col.hidden != true) {
                            result = result + "<th><b>" + col.title + "</b></th>"; // adding Grid header names
                            keysHtml.push(col.field);
                            keysHtmlformat.push(col.format);
                        }
                    }
                }
                result = result + "</tr></thead><tbody>";
            }

            if (executed == 0) {
                if (details.Reply == null || details.Reply == undefined)
                    details.Reply = "";
                result = result + "<tr><td>" + details.Subject + "</td><td>" + details.Message + "</td><td>" + details.Reply + "</td><td>" + details.BranchName + "</td><td>" + details.EmployeeName + "</td><td>" + details.StatusName + "</td><td>" + details.DeletedStatus + "</td><td>" + details.CreatedBy + "</td></tr>";
                executed = 1;
            }
            //"<table id='exportChatTable'><thead><tr><th><b>Subject</b></th><th><b>Message</b></th><th><b>Reply</b></th><th><b>Branch</b></th><th><b>Employee</b></th><th><b>Status</b></th><th><b>Is Deleted</b></th><th><b>Created By</b></th></tr></thead><tbody><tr><td></td><td>How are you?</td><td></td><td>Agali</td><td>CHETAN B U</td><td>Closed</td><td>No</td><td>admin</td></tr>"
            // result="<th><b>Subject</b></th><th><b>Message</b></th><th><b>Reply</b></th><th><b>Branch</b></th><th><b>Employee</b></th><th><b>Status</b></th><th><b>Is Deleted</b></th><th><b>Created By</b></th></tr></thead><tbody><tr><td></td><td>How are you?</td><td></td><td>Agali</td><td>CHETAN B U</td><td>Closed</td><td>No</td><td>admin</td></tr>";
            debugger;
            result = result + "<tr>";
            keysHtml.forEach(function (key, idx) {
                var itemVal = obj[key];
                if (itemVal != null) {
                    var itemVal2 = itemVal.toString();
                }
                else {
                    itemVal = "";
                }

                result = result + "<td>" + itemVal + "</td>";    // adding indivisual cell values
            });
            result = result + "</tr>";
            flag = 1;
        });

        result = result + "</tbody></table>";
        return result;
    }

    $scope.messageGridExcelOptions = {
        columns: [
             {
                 field: "Subject",
                 title: "Subject",
                 width: "80px",
                 filterable: false,


             },
              {
                  field: "Message",
                  title: "Message",
                  width: "80px",
                  filterable: false,


              },
               {
                   field: "Reply",
                   title: "Reply",
                   width: "80px",
                   filterable: false,


               },


            {
                field: "BranchName",
                title: "Branch",
                width: "80px",
                filterable: false,
            },
             {
                 field: "EmployeeName",
                 title: "Employee",
                 width: "80px",
                 filterable: false,
             },



               {
                   field: "StatusName",
                   title: "Status",
                   width: "120px",
                   filterable: false,
               },
                {
                    field: "DeletedStatus",
                    title: "Is Deleted",
                    width: "120px",
                    filterable: false,
                },

               {
                   field: "CreatedBy",
                   title: "Created By",
                   width: "60px",
                   filterable: false,
               },
        ]
    };


    $scope.chartGridExcelOptions = {
        columns: [
            {
                field: "Subject",
                title: "Subject",
                width: "80px",
                filterable: false,


            },
              {
                  field: "Message",
                  title: "Message",
                  width: "80px",
                  filterable: false,


              },
               {
                   field: "Reply",
                   title: "Reply",
                   width: "80px",
                   filterable: false,


               },


            {
                field: "BranchName",
                title: "Branch",
                width: "80px",
                filterable: false,
            },
             {
                 field: "EmployeeName",
                 title: "Employee",
                 width: "80px",
                 filterable: false,
             },



               {
                   field: "StatusName",
                   title: "Status",
                   width: "120px",
                   filterable: false,
               },
                {
                    field: "DeletedStatus",
                    title: "Is Deleted",
                    width: "120px",
                    filterable: false,
                },

               {
                   field: "CreatedBy",
                   title: "Created By",
                   width: "60px",
                   filterable: false,
               },
        ]
    };

    $scope.GroupSearch = function (e) {
        $("#ReportGrid").data("kendoGrid").dataSource.read();

    }
});